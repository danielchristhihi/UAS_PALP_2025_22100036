import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PesananPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Produk'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        // Ambil data produk berdasarkan store yang aktif
        stream: FirebaseFirestore.instance
            .collection('pesanan')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('Tidak ada produk'));
          }

          final pesanan = snapshot.data!.docs;

          return ListView.builder(
            itemCount: pesanan.length,
            itemBuilder: (context, index) {
              final doc = pesanan[index];
              final data = doc.data() as Map<String, dynamic>;

              return ListTile(
                title: Text(data['nama'] ?? 'Tanpa Nama'),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Jumlah: ${data['jumlah']?.toString() ?? '-'}'),
                    Text('Nomor HP: ${data['nomor_hp']?.toString() ?? '-'}'),
                    Text('Pembayaran: ${data['pembayaran']?.toString() ?? '-'}'),
                    Text('Tanggal Pengambilan: ${data['tanggal_ambil'] != null ? (data['created_at'] as Timestamp).toDate().toString() : '-'}'),
                    Text('Tanggal Posting: ${data['tanggal_ambil'] ?? '-'}'),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit, color: Colors.blue),
                      onPressed: () {
                        _showEditDialog(context, doc.id, data['nama'], data['jumlah'], data['nomor_hp'], data['pembayaran'], data['tanggal_ambil']);
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: Text('Hapus Pesanan'),
                            content: Text('Yakin ingin menghapus produk ini?'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(context, false), child: Text('Batal')),
                              TextButton(onPressed: () => Navigator.pop(context, true), child: Text('Hapus')),
                            ],
                          ),
                        );

                        if (confirm == true) {
                          await FirebaseFirestore.instance
                              .collection('pesanan')
                              .doc(doc.id)
                              .delete();
                        }
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _showEditDialog(BuildContext context, String id, String currentName, int currentJumlah, int currentNomorhp, String currentPembayaran, String currentTanggalambil) {
    final namaController = TextEditingController(text: currentName);
    final jumlahController = TextEditingController(text: currentJumlah.toString());
    final nomorhpController = TextEditingController(text: currentNomorhp.toString());
    final pembayaranController = TextEditingController(text: currentPembayaran.toString());
    final tanggalambilController = TextEditingController(text: currentTanggalambil.toString());

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Pesanan'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: namaController,
              decoration: InputDecoration(labelText: 'Nama Produk'),
            ),
            TextField(
              controller: jumlahController,
              decoration: InputDecoration(labelText: 'Jumlah'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: nomorhpController,
              decoration: InputDecoration(labelText: 'Nomor HP'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: pembayaranController,
              decoration: InputDecoration(labelText: 'Pembayaran'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: tanggalambilController,
              decoration: InputDecoration(labelText: 'Tanggal Ambil'),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Batal')),
          TextButton(
            onPressed: () async {
              final nama = namaController.text.trim();
              final jumlah = int.tryParse(jumlahController.text.trim()) ?? 0;
              final nomorhp = int.tryParse(nomorhpController.text.trim()) ?? 0;
              final pembayaran = pembayaranController.text.trim();
              final tanggalambil = tanggalambilController.text.trim();

              if (nama.isNotEmpty) {
                await FirebaseFirestore.instance
                    .collection('pesanan')
                    .doc(id)
                    .update({'nama': nama, 'jumlah': jumlah, 'nomor_hp': nomorhp, 'pembayaran': pembayaran, 'tanggal_ambil': tanggalambil});
              }

              Navigator.pop(context);
            },
            child: Text('Simpan'),
          ),
        ],
      ),
    );
  }
}