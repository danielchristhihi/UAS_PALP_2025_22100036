# poin penilaian

<ol>
    <li><strong>(5 POIN)</strong> Fork repository ini dan memberikan nama repository UAS_PALP_2025_(NIM)</li>
    <li><strong>(10 POIN)</strong> Desain yang digunakan sama dengan yang ada di repository ini</li>
    <li><strong>(20 POIN)</strong> Buatlah firestore dengan struktur data yang sesuai untuk menyimpan data sesuai dengan kebutuhan form</li>
    <li><strong>(20 POIN)</strong> Halaman utama ada 3 layanan cuci helm yang terdiri atas Standar, Advanced, dan Pro. Setiap layanan bisa ditekan tombol "Pesan"-nya dan user harus memasukkan jumlah helm yang akan dicuci, tanggal ambil, nama, no hp, dan tipe pembayaran. Buatlah proses untuk menyimpan data pemesanan ke firestore Anda!</li>
    <li><strong>(20 POIN)</strong> Buatlah satu halaman baru untuk melihat history pemesanan yang diambil dari data firestore Anda! Halaman harus dapat menampilkan history berupa jumlah helm yang akan dicuci, tanggal ambil, nama, no hp, dan tipe pembayaran.</li>
    <li><strong>(10 POIN)</strong> Pada halaman history pemesanan, tambahkan proses edit untuk mengubah history pemesanan</li>
    <li><strong>(10 POIN)</strong> Pada halaman history pemesanan, tambahkan proses delete untuk mengubah history pemesanan</li>
    <li><strong>(5 POIN)</strong> Push pekerjaan Anda ke repository yang telah Anda buat!</li>
    <li><strong> (40 POIN) BONUS: deploy aplikasi Anda!</strong></li>
</ol>
